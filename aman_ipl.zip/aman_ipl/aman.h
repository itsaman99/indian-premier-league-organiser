
int i=0;
int square(int x)
{
	return(x*x);
}
void New(int x)
{
	for(i=0;i<x;i++)
	{
		printf("\n");
	}
}
void dash(int d)
{
	for(i=0;i<d;i++)
	printf("-");
}
void star(int d)
{
	for(i=0;i<d;i++)
	printf("*");
}
void tilde(int d)
{
	for(i=0;i<d;i++)
	printf("~");
}
void line(int x)
{
	int i;
	printf("\n");
	for(i=0;i<x;i++)
	printf("_");
	printf("\n");
}
void tab(int t)
{
	for(i=0;i<t;i++)
	printf("\t");
}
void space(int s)
{
	for(i=0;i<s;i++)
	printf(" ");
}
void percent(int x,int A[20],int t)
{
	int i;
	float avg,sum=0;
	for(i=0;i<x;i++)
	{
		sum=sum+A[i];
	}
	avg=sum*100/t;
	line(50);
	printf("\nyour percentage is %.2f",avg);
	line(50);
}

