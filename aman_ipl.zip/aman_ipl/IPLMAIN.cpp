#include<iostream>
#include<stdio.h>
#include<string.h>         //password for login is "aman@ipl2019"
#include<stdlib.h>
#include<fstream>
#include<conio.h>
#include<iomanip>
#include<windows.h>
#include"aman.h"
void user();
void admin();
void edit_details();
using namespace std;
char win_team[50],lost_team[50];

//class matches_by_date;
class WRAP
{
public:
    WRAP()
    {
	
  		 system("cls");
  		 char wel[80]="WELCOME TO THE INDIAN PREMIER LEAGUE - 2019";New(25);tab(12);
  		 for(int z=0;z<43;z++)
  		 {
  		 	Sleep(60);
  		 	Beep(1600,10);
  		 	cout<<wel[z];
  		 	
  		 	
		   }
		   Sleep(3543);
		   system("cls");
    	New(25);tab(12);cout<<"Opening Simulator...Please Wait...\\";
    	Sleep(111);system("cls");
    	New(25);tab(12);cout<<"Opening Simulator...Please Wait...|";
    	Sleep(111);system("cls");
    	New(25);tab(12);cout<<"Opening Simulator...Please Wait.../";
    	Sleep(111);system("cls");
    	New(25);tab(12);cout<<"Opening Simulator...Please Wait...|";
    	Sleep(111);system("cls");
    	New(25);tab(12);cout<<"Opening Simulator...Please Wait...\\";
    	Sleep(111);system("cls");
    	New(25);tab(12);cout<<"Opening Simulator...Please Wait...|";
    	Sleep(111);system("cls");
    	New(25);tab(12);cout<<"Opening Simulator...Please Wait.../";
    	Sleep(111);system("cls");
    	New(25);tab(12);cout<<"Opening Simulator...Please Wait...|";
    	Sleep(111);
    	system("cls");
    	New(25);tab(12);cout<<"Opening Simulator...Please Wait...\\";
    	Sleep(111);system("cls");
    	New(25);tab(12);cout<<"Opening Simulator...Please Wait...|";
    	Sleep(111);system("cls");
    	New(25);tab(12);cout<<"Opening Simulator...Please Wait.../";
    	Sleep(111);system("cls");
    	New(25);tab(12);cout<<"Opening Simulator...Please Wait...|";
    	Sleep(111);system("cls");
    	New(25);tab(12);cout<<"Opening Simulator...Please Wait...\\";
    	Sleep(111);system("cls");
    	New(25);tab(12);cout<<"Opening Simulator...Please Wait...|";
    	Sleep(111);system("cls");
    	New(25);tab(12);cout<<"Opening Simulator...Please Wait.../";
    	Sleep(111);system("cls");
    	New(25);tab(12);cout<<"Opening Simulator...Please Wait...|";
    	Sleep(111);
    	system("cls");
    	New(25);tab(12);cout<<"Opening Simulator...Please Wait...\\";
    	Sleep(111);system("cls");
    	New(25);tab(12);cout<<"Opening Simulator...Please Wait...|";
    	Sleep(111);system("cls");
    	New(25);tab(12);cout<<"Opening Simulator...Please Wait.../";
    	Sleep(111);system("cls");
    	New(25);tab(12);cout<<"Opening Simulator...Please Wait...|";
    	Sleep(111);system("cls");
    	New(25);tab(12);cout<<"Opening Simulator...Please Wait...\\";
    	Sleep(111);system("cls");
    	New(25);tab(12);cout<<"Opening Simulator...Please Wait...|";
    	Sleep(111);system("cls");
    	New(25);tab(12);cout<<"Opening Simulator...Please Wait.../";
    	Sleep(111);system("cls");
    	New(25);tab(12);cout<<"Opening Simulator...Please Wait...|";
    	Sleep(111);
    	
    	system("cls");
    		New(25);tab(13);cout<<"Loading Data....\n\n\n";
    		char l[150]=">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>";
        for(int j=0;j<20;j++)
        {
        	cout<<l[j];
        	Sleep(35);
		}
		for(int j=0;j<5;j++)
        {
        	cout<<l[j];
        	Sleep(500);
		}
		for(int j=0;j<40;j++)
        {
        	cout<<l[j];
        	Sleep(30);
		}
		for(int j=0;j<10;j++)
        {
        	cout<<l[j];
        	Sleep(100);
		}
		for(int j=0;j<100;j++)
        {
        	cout<<l[j];
        	Sleep(20);
		}
		for(int j=0;j<20;j++)
        {
        	cout<<l[j];
        	Sleep(50);
		}
		for(int j=0;j<42;j++)
        {
        	cout<<l[j];
        	Sleep(15);
		}
    		
        system("cls");
        cout<<"\a";
        system("color 65");
        
        New(3);tab(2);star(206);New(2);tab(2);star(206);New(2);tab(2);star(206);New(2);tab(2);star(206);
    New(8);tab(12);cout<<"+ \t    ____";
    New(1);tab(12);cout<<"|\t   |    |\t  |";
    New(1);tab(12);cout<<"|\t   |    |\t  |";
    New(1);tab(12);cout<<"|\t   |____|\t  |";
    New(1);tab(12);cout<<"|\t   |     \t  |";
    New(1);tab(12);cout<<"|\t   |     \t  |_____";
    New(3);tab(11);cout<<" I N D I A N\t P R E M I E R\t L E A G U E \t-2019";
    New(8);tab(2);star(206);New(2);tab(2);star(206);New(2);tab(2);star(206);New(2);tab(2);star(206);
    New(3);tab(11);cout<<"Cricket league presented  By - Aman Patel";New(3);
	New(2);tab(2);tilde(206);
    New(1);tab(11);cout<<"Opening The User interface...Wait a while....\n\n\n";
    	char s[150]="~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~";
        for(int j=0;j<20;j++)
        {
        	cout<<s[j];
        	Sleep(35);
		}
		for(int j=0;j<5;j++)
        {
        	cout<<s[j];
        	Sleep(500);
		}
		for(int j=0;j<40;j++)
        {
        	cout<<s[j];
        	Sleep(30);
		}
		for(int j=0;j<10;j++)
        {
        	cout<<s[j];
        	Sleep(100);
		}
		for(int j=0;j<100;j++)
        {
        	cout<<s[j];
        	Sleep(20);
		}
		for(int j=0;j<20;j++)
        {
        	cout<<s[j];
        	Sleep(50);
		}
		for(int j=0;j<42;j++)
        {
        	cout<<s[j];
        	Sleep(15);
		}
	Sleep(100);
	
        system("cls");
        system("color F1");
        New(6);tab(7);cout<<"Read the given instruction before you use the INDIAN PREMIER LEAGUE -2019 Simulator : - \n";tab(2);star(206);New(1);
        fstream ins("instructions.txt",ios::in);
        char line[200];
        while(ins)
        {
            ins.getline(line,200);
            New(2);tab(6);cout<<line;
        }
        
        New(1);tab(2);star(206);New(2);tab(12);cout<<"Press the Enter key to Get into Program";New(2);tab(2);tilde(206);getch();
        

    };
};
class USER
{
   protected:
    char name[50],team[100],opp_team[100],batting_type[50],bowling_type[100],role[50],DOB[20],birth_place[50],
	top_score[5],top_bowling[6],id[7];
    char total_runs[10],debut[10],total_matches[10],hundreds[10],fifties[10],wickets[10],average[10];
    public:
        USER()			// constriuctor for storing default value
        {
            strcpy(name,"NA");
			strcpy(team,"NA");
			strcpy(batting_type,"NA");
			strcpy(bowling_type,"NA");
            strcpy(role,"NA");
			strcpy(DOB,"NA");
			strcpy(birth_place,"NA");
			strcpy(top_bowling,"NA");
            strcpy(top_score,"NA");
			strcpy(id,"NA");
			strcpy(total_matches,"NA");
			strcpy(total_runs,"NA");
            strcpy(debut,"NA");
			strcpy(hundreds,"NA");
			strcpy(fifties,"NA");
			strcpy(wickets,"NA");
            strcpy(average,"NA");
        }
   friend void players_list(USER List)
    {					// Showing players list of team.
        start:char ch;
        char team_name[100];
        system("cls");
        New(1);tab(10);cout<<"Select One of the Team below : \n";
    New(3);tab(9);cout<<"[1] Mumbai Indians";
	New(3);tab(9);cout<<"[2] Chennai Super Kings\n";
    New(3);tab(9);cout<<"[3] Rajasthan Royals";
	New(3);tab(9);cout<<"[4] Royal Challengers Bangalore\n";
    New(3);tab(9);cout<<"[5] Kings XI Punjab";
	New(3);tab(9);cout<<"[6] Kolkata Knight Riders\n";
    New(3);tab(9);cout<<"[7] Delhi Daredevils";
	New(3);tab(9);cout<<"[8] Sun Risers Hyderabad\n";
	ch=getch();
    switch(ch)
    {				//taking inputs for team
        case '1' : strcpy(team_name,"Mumbai Indians");
        break;
        case '2' : strcpy(team_name,"Chennai Super Kings");
        break;
        case '3' : strcpy(team_name,"Rajasthan Royals");
        break;
        case '4' : strcpy(team_name,"Royal Challengers Bangalore");
        break;
        case '5' : strcpy(team_name,"Kings XI Punjab");
        break;
        case '6' : strcpy(team_name,"Kolkata Knight Riders");
        break;
        case '7' : strcpy(team_name,"Delhi Daredevils");
        break;
        case '8' : strcpy(team_name,"Sun Risers Hyderabad");
        break;
        default : goto start;
    }

    string team_length=team_name;
    int i=0;
	system("cls");
    fstream Lists;
    Lists.open("profiles.txt",ios::in);
    New(18);tab(10);cout<<"Getting the list of players.. Please Wait...\n\n\n";
    	char l[150]=">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>";
        for(int j=0;j<20;j++)
        {
        	cout<<l[j];
        	Sleep(35);
		}
		for(int j=0;j<5;j++)
        {
        	cout<<l[j];
        	Sleep(500);
		}
		for(int j=0;j<40;j++)
        {
        	cout<<l[j];
        	Sleep(30);
		}
		for(int j=0;j<10;j++)
        {
        	cout<<l[j];
        	Sleep(100);
		}
		for(int j=0;j<100;j++)
        {
        	cout<<l[j];
        	Sleep(20);
		}
		for(int j=0;j<20;j++)
        {
        	cout<<l[j];
        	Sleep(50);
		}
		for(int j=0;j<45;j++)
        {
        	cout<<l[j];
        	Sleep(15);
		}
    Sleep(1000);
    system("cls");
    system("color 0c");
    New(2);tab(13);cout<<"Player List of "<<team_name;
	New(1);tab(13);tilde(team_length.length()+15);New(2);tab(2); tilde(206);New(2);
    tab(8);cout<<"SR no."<<setw(13)<<"Name";tab(3);cout<<setw(30)<<"Player type"<<setw(30);cout<<"Total Matches"<<endl;tab(8);star(120);New(1);
    Lists.read((char*)&List,sizeof(List));
    while(!Lists.eof())
    {
        
            tab(8);cout<<i+1<<setw(13)<<List.name;tab(3);cout<<setw(30)<<"-"<<List.role;cout<<setw(30)<<List.total_matches<<endl;tab(8);star(120);New(1);
        
       i++;
    }
    New(1);tab(13);cout<<"Press any key to continue.........";
	getch();
    }
    friend void search_player(USER Details)
    {
        int check;
        system("cls");
        fstream player;
        player.open("profiles.txt",ios::in|ios::binary);
        char n[50];
        New(5);tab(5);cout<<"Enter the player's Name or Id : ";fflush(stdin);gets(n);
        system("cls");New(8);tab(5);cout<<"Searching for the player..........";
		Sleep(2000);
		system("cls");
		player.read((char*)&Details,sizeof(Details));
        while(player)
        {																					//print the player's information
            if(stricmp(n,Details.name)==0||stricmp(n,Details.id)==0)
            {	  
				 New(8);tab(6);cout<<"player found.....";Sleep(1000);
                system("cls");
                tab(6);dash(strlen(Details.name)+1);
                New(1);tab(6);cout<<Details.name;
                New(1);tab(6);dash(strlen(Details.name)+1);
                New(2);tab(4);cout<<"Country : "<<Details.birth_place;
                New(1);tab(3);cout<<setw(18)<<"Date of Birth : "<<Details.DOB;
                New(2);tab(4);cout<<setw(30)<<"Player Type : "<<Details.role;
				New(1);tab(4);cout<<setw(30)<<"Debut year of IPL : "<<Details.debut;
                New(1);tab(4);cout<<"Total Matches Played in IPL : "<<Details.total_matches;
                New(1);tab(4);cout<<setw(30)<<"Current IPL Team : "<<Details.team;
                New(2);tab(3);cout<<"Batting Section --\n";
                New(1);tab(4);cout<<setw(30)<<"Batting Side : "<<Details.batting_type;
				New(1);tab(4);cout<<setw(30)<<"Total Runs in IPL Career : "<<Details.total_runs;
                New(1);tab(4);cout<<setw(30)<<"Highest individual Score : "<<Details.top_score<<"\t-Against the Team -\t"<<Details.opp_team;
                New(1);tab(4);cout<<setw(30)<<"No. of 100's : "<<Details.hundreds;
				New(1);tab(4);cout<<setw(30)<<"No. of 50's : "<<Details.fifties;
                New(1);tab(4);cout<<setw(30)<<"Batting Average : "<<Details.average;
           		 New(2);tab(3);cout<<"Bowling Section --\n";
                New(1);tab(4);cout<<setw(30)<<"Bowler type : "<<Details.bowling_type;
                New(1);tab(4);cout<<setw(30)<<"Total Wickets in Career : "<<Details.wickets;
				New(1);tab(4);cout<<setw(30)<<"Best bowling performance : "<<Details.top_bowling;	
			
              New(2);tab(8);star(200);
                check=1;
            }
        }
        if(check!=1)
        {
            system("cls");
            New(8);tab(5);cout<<"Sorry...No such player is found............";
            Sleep(2000);
        }
        New(2);tab(9);cout<<"Press any Key To Continue................";getch();


    }
    void see_schedule()
    {						// disply match schedule.
        system("cls");
        system("color F1");
        New(11);tab(12);cout<<"Please Wait....";
        Sleep(3000);
         New(3);tab(10);cout<<"Loading the Schedule now....\n\n";
         	char l[150]="________________________________________________________________________________________________________________";
        for(int j=0;j<20;j++)
        {
        	cout<<l[j];
        	Sleep(35);
		}
		for(int j=0;j<5;j++)
        {
        	cout<<l[j];
        	Sleep(500);
		}
		for(int j=0;j<40;j++)
        {
        	cout<<l[j];
        	Sleep(30);
		}
		for(int j=0;j<10;j++)
        {
        	cout<<l[j];
        	Sleep(100);
		}
		for(int j=0;j<100;j++)
        {
        	cout<<l[j];
        	Sleep(20);
		}
		for(int j=0;j<20;j++)
        {
        	cout<<l[j];
        	Sleep(50);
		}
		for(int j=0;j<45;j++)
        {
        	cout<<l[j];
        	Sleep(15);
		}
        system("cls");
        system("color 94");
        tab(4);cout<<"INDIAN PREMIER LEAGUE 2019 - Match Schedule\n";
        tab(4);dash(43);New(1);line(120);
        char a[200];
    ifstream schedule("ipl_shedule.txt");
    while(schedule)
    {
        schedule.getline(a,200);
        tab(5);cout<<endl<<a<<endl;
        i++;
    }
    
    New(2);tab(5);cout<<"Press any key to continue.........";
    getch();
    }
    
    void see_by_date()
    {
    int e=0;
    system("cls");
    char a[200];
    New(8);tab(12);cout<<"Enter the Date to search the matches : ";
	string d;
	cin>>d;New(2);
	
	tab(12);cout<<"Choose the month below:\n";
	tab(13);cout<<"[1] March\n";
	tab(13);cout<<"[2] April\n";
	tab(13);cout<<"[3] May\n";
	char mon;mon=getch();
	char mont[10];
	switch(mon)
	{
		case '2': strcpy(mont,"April");
		break;
		case '1': strcpy(mont,"March");
		break;
		case '3': strcpy(mont,"May");
		break;
	}
    d=d+" "+mont;
    New(7);tab(11);cout<<"Hang on !!!! Getting the details....\n\n\n";
    
    	char l[150]=">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>";
        for(int j=0;j<20;j++)
        {
        	cout<<l[j];
        	Sleep(35);
		}
		for(int j=0;j<5;j++)
        {
        	cout<<l[j];
        	Sleep(500);
		}
		for(int j=0;j<40;j++)
        {
        	cout<<l[j];
        	Sleep(30);
		}
		for(int j=0;j<10;j++)
        {
        	cout<<l[j];
        	Sleep(600);
		}
		for(int j=0;j<100;j++)
        {
        	cout<<l[j];
        	Sleep(20);
		}
		for(int j=0;j<20;j++)
        {
        	cout<<l[j];
        	Sleep(28);
		}
		for(int j=0;j<45;j++)
        {
        	cout<<l[j];
        	Sleep(15);
		}
    system("cls");
    system("color 74");
    tab(5);cout<<"Matches on : ["<<d<<"] - ";New(2);
    fstream date("ipl_shedule.txt",ios::in);
    for(int i=0;i<2;i++)
    {
        date.getline(a,200);
        cout<<a<<endl;
    }
    while(date)
    {
        date.getline(a,200);
        if(d.compare(0,d.length(),a,0,d.length())==0)
        {
            New(1);cout<<a<<endl;
            e=1;
        }
    }
    if(e!=1)
    {
        New(2);tab(5);cout<<"Sorry no match found... "<<d;goto last;
    }
    New(1);dash(54);cout<<"No more Data";dash(54);New(1);
    last:New(4);tab(5);cout<<"Press any key to continue.........";getch();
	}
};
class Admin
{
	private:
		friend void change_bio(Admin);
    friend void update_rec(Admin);
    friend void delete_player(Admin);
    friend class matches_by_date;

    char name[50],team[100],opp_team[100],batting_type[50],bowling_type[100],role[50],DOB[20],birth_place[50],
	top_score[5],top_bowling[6],id[7];
    char total_runs[10],debut[10],total_matches[10],hundreds[10],fifties[10],wickets[10],average[10];
    public:
        Admin()
        {
            strcpy(name,"NA");strcpy(team,"NA");strcpy(batting_type,"NA");strcpy(bowling_type,"NA");
            strcpy(role,"NA");strcpy(DOB,"NA");strcpy(birth_place,"NA");strcpy(top_bowling,"NA");
            strcpy(top_score,"NA");strcpy(id,"NA");strcpy(total_matches,"NA");strcpy(total_runs,"NA");
            strcpy(debut,"NA");strcpy(hundreds,"NA");strcpy(fifties,"NA");strcpy(wickets,"NA");
            strcpy(average,"NA");
        }
    void add_player(void)
    
{ 

	 ag_ain:system("cls");
    New(1);tab(5);cout<<"Select the team to which Player Belongs : \n";
    New(3);tab(4);cout<<"[1] Mumbai Indians\t[2] Chennai Super Kings\n";
    New(2);tab(4);cout<<"[3] Rajasthan Royals\t[4] Royal Challengers Bangalore\n";
    New(2);tab(4);cout<<"[5] Kings XI Punjab\t[6] Kolkata Knight Riders\n";
    New(2);tab(4);cout<<"[7] Delhi Daredevils\t[8] Sun Risers Hyderabad\n";
    char team_b;team_b=getch();
    switch(team_b)
    {
        case '1' : strcpy(team,"Mumbai Indians");
        break;
        case '2' : strcpy(team,"Chennai Super Kings");
        break;
        case '3' : strcpy(team,"Rajasthan Royals");
        break;
        case '4' : strcpy(team,"Royal Challengers Bangalore");
        break;
        case '5' : strcpy(team,"Kings XI Punjab");
        break;
        case '6' : strcpy(team,"Kolkata Knight Riders");
        break;
        case '7' : strcpy(team,"Delhi Daredevils");
        break;
        case '8' : strcpy(team,"Sun Risers Hyderabad");
        break;
        default : goto ag_ain;
    }
    
   
    char coun;
    system("cls");
    New(5);tab(5);cout<<"Enter name of the Player : ";fflush(stdin);cin>>name;
    
  	New(5);
    New(1);tab(5);cout<<"Enter the player's Date of Birth [DD-MM-YYYY] : ";fflush(stdin);cin>>DOB;
    
    New(3);tab(5);cout<<"Enter player id : ";cin>>id;
   
    role:system("cls");
    New(1);tab(4);cout<<"Select the player type : ";New(4);tab(4);cout<<"[1] Batsman\t[2] Bowler\t[3] All Rounder\t[4] Wicketkeeper";
    char type;type=getch();
    switch(type)
    {
        case '1' : strcpy(role,"Batsman");
        break;
        case '2' : strcpy(role,"Bowler");
        break;
        case '3' : strcpy(role,"All Rounder");
        break;
        case '4' : strcpy(role,"Wicketkeeper");
        break;
        default : goto role;
    }
    batting:system("cls");
    New(1);tab(5);cout<<"Choose player's Batting type : \n";
    New(4);
   tab(4);cout<<"[1] Left Handed Batsman\t\t[2] Right Handed Batsman";
    char bat_type;bat_type=getch();
    switch(bat_type)
    {
        case '1' : strcpy(batting_type,"Right");
        break;
        case '2' : strcpy(batting_type,"Left");
        break;
        default : goto batting;
    }
    
    
     system("cls");
    New(5);tab(5);cout<<"Total Number of wickets taken : ";fflush(stdin);cin>>wickets;
    New(1);tab(5);cout<<"Top Bowling performance [format : wickets/runs] : ";fflush(stdin);cin>>top_bowling;
	
    system("cls");
    New(1);tab(5);cout<<"Total Matches Played By player in IPL career : ";fflush(stdin);cin>>total_matches;
    New(1);tab(5);cout<<"Player's Debut Year in IPL : 20";fflush(stdin);cin>>debut;char tw[3];strcpy(tw,"20");
    strcpy(debut,strcat(tw,debut));
    New(1);tab(5);cout<<"Total Runs of the player in IPL Career : ";cin>>total_runs;
    New(1);tab(5);cout<<"Highest individual score of player : ";fflush(stdin);cin>>top_score;
    n_ag_ain:system("cls");
    New(1);tab(5);cout<<"Highest Score Made Against team : ";fflush(stdin);
     New(5);tab(4);cout<<"[1] Mumbai Indians\t[2] Chennai Super Kings\n";
    New(2);tab(4);cout<<"[3] Rajasthan Royals\t[4] Royal Challengers Bangalore\n";
    New(2);tab(4);cout<<"[5] Kings XI Punjab\t[6] Kolkata Knight Riders\n";
    New(2);tab(4);cout<<"[7] Delhi Daredevils\t[8] Sun Risers Hyderabad\n";
    char team_c;team_c=getch();
    switch(team_c)
    {
        case '1' : strcpy(opp_team,"Mumbai Indians");
        break;
        case '2' : strcpy(opp_team,"Chennai Super Kings");
        break;
        case '3' : strcpy(opp_team,"Rajasthan Royals");
        break;
        case '4' : strcpy(opp_team,"Royal Challengers Bangalore");
        break;
        case '5' : strcpy(opp_team,"Kings XI Punjab");
        break;
        case '6' : strcpy(opp_team,"Kolkata Knight Riders");
        break;
        case '7' : strcpy(opp_team,"Delhi Daredevils");
        break;
        case '8' : strcpy(opp_team,"Sun Risers Hyderabad");
        break;
        default : goto n_ag_ain;
    }
    system("cls");
    New(5);tab(5);cout<<"Player's Batting Average in IPL : ";fflush(stdin);cin>>average;
    system("cls");
    New(5);tab(5);cout<<"No. of 100's Made by player : ";fflush(stdin);cin>>hundreds;
    New(1);tab(5);cout<<"No. of 50's Made by Player : ";fflush(stdin);cin>>fifties;
   
 

    system("cls");New(6);tab(5);cout<<"Player Added successfully............";Sleep(1500);

}
    

};
class matches_by_date
{
    char team_a[50],team_b[50],team_won[50],team_lost[50],
    id_mom[10],id_pc[10],id_oc[10],m_match[50],o_cap[50],p_cap[50],date1[20],month[7],may[5],march[7],
    april[7],day[3],m_perform[30],p_perform[30],o_perform[30],m_runs[6],p_runs[6],m_wick[6],o_wick[6],p_wick[6],stadium[200],time1[10];
public:
    matches_by_date()
    {	strcpy(march,"march");
        strcpy(may," May");
        strcpy(april," April");
    }
    void see_man_match(matches_by_date m)
    {
        r_agr:system("cls");
        New(6);tab(10);cout<<"[1] Search By date";
        New(2);tab(10);cout<<"[2] See all";
        char g=getch();
    switch(g)
    {
    case '1' :{
                system("cls");
                New(7);tab(6);cout<<"Enter the date to search the match : (don't write the month) : ";char dayt[5];cin>>dayt;
                d_ag:
                New(2);tab(5);cout<<"Select the month:\n";char mon[8],mo_n;
                New(1);tab(6);cout<<"[1] March";
				New(1);tab(6);cout<<"[2] April";
				New(1);tab(6);cout<<"[3] May"
				;mo_n=getch();
                if(mo_n=='1')strcpy(mon," March");
                else if (mo_n=='2')strcpy(mon," April");
                else if (mo_n=='3')strcpy(mon," May");
                else goto d_ag;
                char datt[11];
                strcpy(datt,strcat(dayt,mon));
                
				New(4);tab(11);cout<<"Searching for the match on "<<datt<<" .........";Sleep(2500);
                fstream m_matc;
                m_matc.open("dates_match_details.txt",ios::in);
                int e=1;
                while(m_matc.read((char*)&m,sizeof(m)))
                {
                    if(stricmp(datt,m.date1)==0)
                    {
                        New(3);tab(11);cout<<"Match Found...Please Hold on...";
                        char l[150]="________________________________________________________________________________________________________________";
        for(int j=0;j<20;j++)
        {
        	cout<<l[j];
        	Sleep(35);
		}
		for(int j=0;j<5;j++)
        {
        	cout<<l[j];
        	Sleep(500);
		}
		for(int j=0;j<40;j++)
        {
        	cout<<l[j];
        	Sleep(30);
		}
		for(int j=0;j<10;j++)
        {
        	cout<<l[j];
        	Sleep(100);
		}
		for(int j=0;j<100;j++)
        {
        	cout<<l[j];
        	Sleep(20);
		}
		for(int j=0;j<20;j++)
        {
        	cout<<l[j];
        	Sleep(50);
		}
		for(int j=0;j<45;j++)
        {
        	cout<<l[j];
        	Sleep(15);
		}
                        system("cls");
                        New(4);tab(7);cout<<"Date : "<<m.date1;
                    New(3);tab(3);cout<<setw(30)<<m.team_a<<"\t\tVs\t"<<m.team_b;New(2);
                    tab(6);cout<<"Team Won : "<<m.team_won;New(2);
                    tab(3);cout<<"Man of the match : "<<m.m_match;tab(2);cout<<"Performance : "<<m.m_perform;
                    e=1;
                    break;
                    }
                    else e=0;
                }
                if(e!=1)
                {
                    New(7);tab(5);cout<<"No matches found on... "<<datt<<"...........";Sleep(1500);
                }
    }
                break;

        case '2' :{ system("cls");
            fstream m_matc;
            New(3);tab(11);cout<<"Getting the list....\n\n\n";
            char l[150]=">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>";
        for(int j=0;j<20;j++)
        {
        	cout<<l[j];
        	Sleep(35);
		}
		for(int j=0;j<5;j++)
        {
        	cout<<l[j];
        	Sleep(500);
		}
		for(int j=0;j<40;j++)
        {
        	cout<<l[j];
        	Sleep(30);
		}
		for(int j=0;j<10;j++)
        {
        	cout<<l[j];
        	Sleep(100);
		}
		for(int j=0;j<100;j++)
        {
        	cout<<l[j];
        	Sleep(20);
		}
		for(int j=0;j<20;j++)
        {
        	cout<<l[j];
        	Sleep(50);
		}
		for(int j=0;j<45;j++)
        {
        	cout<<l[j];
        	Sleep(15);
		}
            
            m_matc.open("dates_match_details.txt",ios::in);
            while(m_matc.read((char*)&m,sizeof(m)))
            {
                New(1);cout<<setw(9)<<m.date1;tab(1);cout<<setw(30)<<m.team_a<<"\t\tVs\t"<<m.team_b;New(2);
                tab(5);cout<<"Team Won : "<<m.team_won;New(2);
                tab(2);cout<<"Man of the match : "<<m.m_match;tab(2);cout<<"Performance : "<<m.m_perform;New(1);dash(120);
            }}
        break;
        default : goto r_agr;
    }
        New(3);tab(4);cout<<"Press any key to continue.........";getch();
    }
    void select_team(char team[50],char* sel)
    {
      t_ag_ain:  system("cls");
    New(1);tab(5);cout<<sel<<"\n";
    New(3);tab(4);cout<<"[1] Mumbai Indians\t[2] Chennai Super Kings\n";
    New(2);tab(4);cout<<"[3] Rajasthan Royals\t[4] Royal Challengers Bangalore\n";
    New(2);tab(4);cout<<"[5] Kings XI Punjab\t[6] Kolkata Knight Riders\n";
    New(2);tab(4);cout<<"[7] Delhi Daredevils\t[8] Sun Risers Hyderabad\n";
    char team_b;team_b=getch();
    switch(team_b)
    {
        case '1' : strcpy(team,"Mumbai Indians");
        break;
        case '2' : strcpy(team,"Chennai Super Kings");
        break;
        case '3' : strcpy(team,"Rajasthan Royals");
        break;
        case '4' : strcpy(team,"Royal Challengers Bangalore");
        break;
        case '5' : strcpy(team,"Kings XI Punjab");
        break;
        case '6' : strcpy(team,"Kolkata Knight Riders");
        break;
        case '7' : strcpy(team,"Delhi Daredevils");
        break;
        case '8' : strcpy(team,"Sun Risers Hyderabad");
        break;
        default : goto t_ag_ain;
    }
    }
     void update_m_d(Admin A)
    {
        date_ag:system("cls");
        New(3);tab(4);cout<<"Enter the day of the match (eg. Enter 5 ) : ";cin>>day;
        int dd = atoi(day);
        if(dd>31||dd<1)
        {
            New(2);tab(3);cout<<"Please Enter Day in between 1-31.";getch();
            goto date_ag;
        }
        m_again:
		system("cls");
		New(2);tab(4);cout<<"Choose the month :";
		New(2);tab(5);cout<<"[1] March";
		New(2);tab(5);cout<<"[2] April";
		New(2);tab(5);cout<<"[3] May";
		char m;m=getch();
        switch(m)
        {
            case '1' : strcpy(month,"march");
            break;
            case '2' : strcpy(month,"april");
            break;
            case '3' : strcpy(month,"may");
            break;
            default : goto m_again;
        }
        strcpy(date1,strcat(day,month));
        time_ag:system("cls");
        New(2);tab(3);cout<<"Choose the time for the match : ";
        New(2);tab(4);cout<<"[1] 4:00 PM";
		New(1);tab(2);cout<<"[2] 8:00 PM";
        char ti;ti=getch();
        if(ti=='1')
        strcpy(time1,"4:00 PM");
        else if(ti=='2')
            strcpy(time1,"8:00 PM");
        else
            goto time_ag;
        //-----------------------------------------------------------------------------------------------------------------//
        stad_ag:system("cls");
        New(8);tab(12);cout<<"Loading Stadiums for match......\n\n\n";
        char l[100]="_________________________________________________________________________________________________";
        for(int j=0;j<20;j++)
        {
        	cout<<l[j];
        	Sleep(35);
		}
		for(int j=0;j<5;j++)
        {
        	cout<<l[j];
        	Sleep(500);
		}
		for(int j=0;j<40;j++)
        {
        	cout<<l[j];
        	Sleep(30);
		}
		for(int j=0;j<10;j++)
        {
        	cout<<l[j];
        	Sleep(100);
		}
		for(int j=0;j<100;j++)
        {
        	cout<<l[j];
        	Sleep(20);
		}
		for(int j=0;j<20;j++)
        {
        	cout<<l[j];
        	Sleep(50);
		}
		for(int j=0;j<45;j++)
        {
        	cout<<l[j];
        	Sleep(15);
		}
		New(2);
        char z1 = 'a';
        {
            fstream st("stadiums.txt",ios::in);
            char st1[200];
            while(st)
            {
                st.getline(st1,200);
                New(1);tab(1);cout<<z1<<"]\t"<<st1;
                New(1);tab(1);dash(78);
                z1++;
                if(z1=='n')
                    break;
            }
            cout<<" Enter your response : ";char res;res=getche();
            if(res=='a')strcpy(stadium,"Holkar Stadium , Indore , Madhya Pradesh");
            else if(res=='b')strcpy(stadium,"M. Chinnaswami Stadium , Bangalore , Karnataka");
            else if(res=='c')strcpy(stadium,"PCA Stadium , Mohali , Punjab");
            else if(res=='d')strcpy(stadium,"Feroz Shah Kotla Ground , Delhi");
            else if(res=='e')strcpy(stadium,"Eden Gardens , Kolkata , West Bengal");
            else if(res=='f')strcpy(stadium,"Wankhede Stadium , Mumbai , Maharashtra");
            else if(res=='g')strcpy(stadium,"Sawai Mansingh Stadium , Jaipur , Rajasthan");
            else if(res=='h')strcpy(stadium,"Rajiv Gandhi International Cricket Stadium , Hyderabad , Telangana");
            else if(res=='i')strcpy(stadium,"M. A. Chidambaram Stadium , Chennai , Tamilnadu");
            else if(res=='j')strcpy(stadium,"Green Park Stadium , Kanpur , Uttar Pradesh");
            else if(res=='k')strcpy(stadium,"Saurashtra Cricket Association Stadium , Rajkot , Gujrat");
            else if(res=='l')strcpy(stadium,"VCA Stadium , Nagpur , Maharashtra");
            else if(res=='m')strcpy(stadium,"HCPA Stadium , Dharamshala , Punjab");
            else goto stad_ag;
        }
        char sel_a[50],sel_b[50];
        strcpy(sel_a,"Please select the team A");
        strcpy(sel_b,"Please select the team B");
        select_team(team_a,sel_a);
        system("cls");New(8);tab(5);cout<<"selecting '"<<team_a<<"' as Team A..........";Sleep(1500);
        te_am_a:select_team(team_b,sel_b);
        if(stricmp(team_b,team_a)==0)
        {
            system("cls");
            New(5);tab(5);cout<<team_a<<" already selected as team A";
            New(5);tab(5);cout<<"Press Enter to select again.....";getch();
            goto te_am_a;
        }
        system("cls");New(8);tab(5);cout<<"selecting '"<<team_b<<"' as Team B..........";Sleep(1500);
        w_again:system("cls");New(4);tab(5);cout<<"Which team won the match ?\n";
        New(3);tab(5);cout<<"[1] "<<team_a;
        New(2);tab(5);cout<<"[2] "<<team_b;char w;w=getch();
        switch(w)
        {
            case '1' : strcpy(team_won,team_a);
                       strcpy(team_lost,team_b);
            break;
            case '2' : strcpy(team_won,team_b);
                       strcpy(team_lost,team_a);
            break;
            default: goto w_again;
        }
        system("cls");

        int i=1;
        New(4);tab(2);cout<<"Won : "<<team_won<<endl;New(1);tab(2);cout<<"lost : "<<team_lost;getch();
        system("cls");
        fstream ch,io;
        ch.open("profiles.txt",ios::in);
        io.open("temp.txt",ios::out);
        while(ch.read((char*)&A,sizeof(A)))
        {
            if(stricmp(team_won,A.team)==0)
            {
                New(2);tab(4);cout<<i<<". "<<A.name<<"\t\tid : "<<A.id;
                int mat = atoi(A.total_matches);
                mat+=1;
                char ma_t[6];
                itoa(mat,ma_t,10);
                strcpy(A.total_matches,ma_t);
                i++;
                io.write((char*)&A,sizeof(A));
            }
            else if(stricmp(team_lost,A.team)==0)
            {
                int mat = atoi(A.total_matches);
                mat+=1;
                char ma_t[6];
                itoa(mat,ma_t,10);
                strcpy(A.total_matches,ma_t);
                io.write((char*)&A,sizeof(A));
            }
            else
                io.write((char*)&A,sizeof(A));
        }
        ch.close();
        io.close();
        remove("profiles.txt");
        rename("temp.txt","profiles.txt");
        remove("temp.txt");
        ch.open("profiles.txt",ios::in);
        New(2);tab(4);cout<<"Write the id of the man of the match : ";fflush(stdin);gets(id_mom);
        New(2);tab(4);cout<<"Write the id orange cap holder : ";fflush(stdin);gets(id_pc);
        New(3);tab(4);cout<<"Write the id of purple cap holder : ";fflush(stdin);gets(id_oc);
        char p_type[10],prev_runs_m[5],prev_runs_p[5],prev_wick_m[5],prev_wick_o[5];
        while(ch.read((char*)&A,sizeof(A)))
        {
            if(strcmp(id_mom,A.id)==0)
            {
                strcpy(m_match,A.name);
                strcpy(p_type,A.role);
                strcpy(prev_runs_m,A.top_score);
                strcpy(prev_wick_m,A.top_bowling);
            }
            if(strcmp(id_pc,A.id)==0)
            {
                strcpy(p_cap,A.name);
                strcpy(prev_runs_p,A.top_score);
            }
            if(strcmp(id_oc,A.id)==0)
            {
                strcpy(o_cap,A.name);
                strcpy(prev_wick_o,A.top_bowling);
            }
        }
        ch.close();
        system("cls");
        New(3);tab(4);cout<<"Man of the match is : "<<m_match<<" and player type : "<<p_type;
        New(3);tab(2);cout<<"What do you wish to reward Man of the match for :";
        New(2);tab(3);cout<<"[1] Batting performance \t[2] Bowling performance";char p1;p1=getch();
        switch(p1)
        {
            case '1' :{
                           char mo_runs[6];
                           sc_again: New(2);tab(4);cout<<"Enter the score for this match : ";cin>>m_runs;char no[10];
                           New(2);tab(3);cout<<"Made in balls (write no. of balls played by batsman) : ";char ball[10];cin>>ball;
                           if(m_runs[strlen(m_runs)]=='*')
                           {
                               strncpy(no,m_runs,strlen(m_runs));
                           }
                           else
                            strcpy(no,m_runs);
                           int n_score = atoi(no);
                           string s1=prev_runs_m;char nn[10];
                           if(prev_runs_m[strlen(prev_runs_m)]=='*')
                           {
                               strncpy(nn,prev_runs_m,strlen(prev_runs_m));
                           }
                           else
                            strcpy(nn,prev_runs_m);
                           int a = atoi(nn);// highest individual score
/*Start writing into the file*/         fstream change,temp;                                                                //Ashutosh Singhai
                                        change.open("profiles.txt",ios::in);
                                        temp.open("temp.txt",ios::out);
                                        while(change.read((char*)&A,sizeof(A)))
                                        {
                                            if(stricmp(m_match,A.name)==0)
                                            {

                     /*modifying total runs*/   int tr = atoi(A.total_runs);
                                                tr+=n_score;
                                                char t_r[5];
                                                itoa(tr,t_r,10);
                                                strcpy(A.total_runs,t_r);
   /*if the score is greater than highest*/     if(n_score>a)
                                                {
                                                    strcpy(A.top_score,m_runs);
                                                }
               /*if score is > = 100*/          if(n_score>=100)
                                                {
                                                    int r = atoi(A.hundreds);
                                                    r++;
                                                    char h[5];
                                                    itoa(r,h,10);
                                                    strcpy(A.hundreds,h);
                                                }
        /*if score is > = 50 and < 100*/        if(n_score>=50&&n_score<100)
                                                {
                                                    int r = atoi(A.fifties);
                                                    r++;
                                                    char h[5];
                                                    itoa(r,h,10);
                                                    strcpy(A.fifties,h);
                                                }
                                                strcpy(A.opp_team,team_lost);
                                                temp.write((char*)&A,sizeof(A));
                                            }
                                            else
                                            temp.write((char*)&A,sizeof(A));
                                        }
                                                    temp.close();
                                                    change.close();
                                                    remove("profiles.txt");
                                                    rename("temp.txt","profiles.txt");
    /*Ending th file*/                              remove("temp.txt");
                           char ist[20];
                           strcpy(ist,strcat(m_runs," runs in "));
                           char iist[20];
                           strcpy(iist,strcat(ball," balls"));
                           strcpy(m_perform,strcat(ist,iist));

            }
            break;
            case '2' :{
                          New(2);tab(4);cout<<"Enter the bowling performance of this match (eg. 3/25 ): ";cin>>m_wick;
                           string s1=prev_wick_m;char nn[10];
                           strncpy(nn,prev_wick_m,(s1.find("/")));
                           int a = atoi(nn);
                           char nw[10];
                           string s2=m_wick;
                           strncpy(nw,m_wick,(s2.find("/")));
                           int b = atoi(nw);
                               fstream change,temp;
                                change.open("profiles.txt",ios::in);
                                temp.open("temp.txt",ios::out);
                               while(change.read((char*)&A,sizeof(A)))
                                        {
                                            if(stricmp(m_match,A.name)==0)
                                            {
     /*if new is greater than top bowling*/     if(b>a)
                                                {
                                                    strcpy(A.top_bowling,m_wick);
                                                }
           /*add wickets to total wickets*/     int we = atoi(A.wickets);
                                                we = we+b;
                                                char w_e[5];
                                                itoa(we,w_e,10);
                                                strcpy(A.wickets,w_e);
                                                temp.write((char*)&A,sizeof(A));
                                            }
                                            else
                                            temp.write((char*)&A,sizeof(A));
                                        }
                                                    temp.close();
                                                    change.close();
                                                    remove("profiles.txt");
                                                    rename("temp.txt","profiles.txt");
                                                    remove("temp.txt");
                           strcpy(m_perform,m_wick);
            }
            break;
        }
        New(2);tab(3);cout<<"Press any key to continue..............";getch();
        system("cls");
        New(4);tab(4);cout<<"Purple cap holder : "<<o_cap;
        {
                          New(2);tab(4);cout<<"Enter the bowling performance of this match (eg. 3/25 ): ";cin>>o_wick;
                           string s1=prev_wick_o;char nn[10];
                           strncpy(nn,prev_wick_o,(s1.find("/")));
                           int a = atoi(nn);
                           char nw[10];
                           string s2=o_wick;
                           strncpy(nw,o_wick,(s2.find("/")));
                           int b = atoi(nw);
                               fstream change,temp;
                                change.open("profiles.txt",ios::in);
                                temp.open("temp.txt",ios::out);
                               while(change.read((char*)&A,sizeof(A)))
                                        {
                                            if(stricmp(o_cap,A.name)==0)
                                            {
                                                if(b>a)
                                                {
                                                    strcpy(A.top_bowling,o_wick);
                                                }
                                                int we = atoi(A.wickets);
                                                we = we+b;
                                                char w_e[5];
                                                itoa(we,w_e,10);
                                                strcpy(A.wickets,w_e);
                                                temp.write((char*)&A,sizeof(A));
                                            }
                                            else
                                            temp.write((char*)&A,sizeof(A));
                                        }
                                                    temp.close();
                                                    change.close();
                                                    remove("profiles.txt");
                                                    rename("temp.txt","profiles.txt");
                                                    remove("temp.txt");
                           strcpy(o_perform,o_wick);
            }

        New(2);tab(3);cout<<"Press any key to continue..............";getch();
        system("cls");
        New(4);tab(4);cout<<"Orange cap Holder : "<<p_cap;
        char mo_runs[6];
                          New(2);tab(4);cout<<"Enter the score for this match : ";cin>>p_runs;char no[10];
                           New(2);tab(3);cout<<"Made in balls (write no. of balls played by batsman) : ";char ball[10];cin>>ball;
                           if(p_runs[strlen(p_runs)]=='*')
                           {
                               strncpy(no,p_runs,strlen(p_runs));
                           }
                           else
                            strcpy(no,p_runs);
                           int n_score = atoi(no);
                           string s1=prev_runs_p;char nn[5];
                           if(prev_runs_p[strlen(prev_runs_p)]=='*')
                           {
                               strncpy(nn,prev_runs_p,strlen(prev_runs_p));
                           }
                           else
                            strcpy(nn,prev_runs_p);
                           int a = atoi(nn);// highest individual score
                                        fstream change,temp;
                                        change.open("profiles.txt",ios::in);
                                        temp.open("temp.txt",ios::out);
                                        while(change.read((char*)&A,sizeof(A)))
                                        {
                                            if(stricmp(p_cap,A.name)==0)
                                            {
                                                if(n_score>a)
                                                {
                                                    strcpy(A.top_score,p_runs);
                                                }
                                                int tot = atoi(A.total_runs);
                                                tot+=n_score;
                                                char tt[5];
                                                itoa(tot,tt,10);
                                                strcpy(A.total_runs,tt);
                                                strcpy(A.opp_team,team_lost);
                                                if(n_score>=100)
                                                {
                                                    int r = atoi(A.hundreds);
                                                    r++;
                                                    char h[5];
                                                    itoa(r,h,10);
                                                    strcpy(A.hundreds,h);
                                                }
                                                 if(n_score>=50&&n_score<100)
                                                {
                                                    int r = atoi(A.fifties);
                                                    r++;
                                                    char h[5];
                                                    itoa(r,h,10);
                                                    strcpy(A.fifties,h);
                                                }
                                                temp.write((char*)&A,sizeof(A));
                                            }
                                            else
                                            temp.write((char*)&A,sizeof(A));
                                        }
                                                    temp.close();
                                                    change.close();
                                                    remove("profiles.txt");
                                                    rename("temp.txt","profiles.txt");
                                                    remove("temp.txt");
                           char ist[20];
                           strcpy(ist,strcat(p_runs," runs in "));
                           char iist[20];
                           strcpy(iist,strcat(ball," balls"));
                           strcpy(p_perform,strcat(ist,iist));
    New(2);tab(3);cout<<"Press any key to continue..............";getch();
    strcpy(win_team,team_won);
    strcpy(lost_team,team_lost);
    }
    friend void search_match(matches_by_date p)
    {
        char mon[10],day1[3],date2[20];
        system("cls");
        New(6);tab(5);cout<<"Write the date of the match (eg type 8) : ";cin>>day1;
        m_again:New(2);tab(4);cout<<"Choose the month : \t[1] April\t\t[2] May";char m;m=getch();
        switch(m)
        {
        	case '1' : strcpy(mon," March");
            break;
            case '2' : strcpy(mon," April");
            break;
            case '3' : strcpy(mon," May");
            break;
            default : goto m_again;
        }
        strcpy(date2,strcat(day1,mon));
        cout<<"\nDate selected is "<<date2;
        fstream ge("dates_match_details.txt",ios::in);
        while(ge.read((char*)&p,sizeof(p)))
        {
            if(stricmp(date2,p.date1)==0)
            {
                system("cls");
                New(1);tab(1);cout<<"Date of the match : "<<date2;tab(6);cout<<"Time : "<<p.time1;
                New(1);tab(1);cout<<"Venue : "<<p.stadium;
                New(3);tab(3);cout<<setw(30)<<p.team_a<<"\t\tVs\t\t"<<p.team_b;
                New(1);tab(4);cout<<"-";dash(strlen(p.team_a)+strlen("\t\tVs\t\t")+strlen(p.team_b)+35);
                New(3);tab(5);dash(15+strlen(p.team_won));
                New(1);tab(5);cout<<"Winning Team : "<<p.team_won;
                New(1);tab(5);dash(15+strlen(p.team_won));
                New(2);tab(3);cout<<setw(20)<<"Man of the match : "<<p.m_match<<"\twith performance : "<<p.m_perform;
                New(2);tab(3);cout<<"Orange cap holder : "<<p.p_cap<<"\twith performance : "<<p.p_perform;
                New(2);tab(3);cout<<"Purple cap holder : "<<p.o_cap<<"\twith performance : "<<p.o_perform;
            }
        }
        getch();
    }
};

void change_bio(Admin A)
{
    int n;
    system("cls");
    New(5);tab(4);cout<<"Enter the name of the player to change details : ";char name_s[50];gets(name_s);
    fstream change,temp;
    char c;
    change.open("profiles.txt",ios::in);
    temp.open("temp.txt",ios::out);
    while(change.read((char*)&A,sizeof(A)))
    {
        if(stricmp(name_s,A.name)==0)
        {
            system("cls");
            New(5);tab(5);cout<<"[1] Update name";
            New(2);tab(5);cout<<"[2] Update DOB";
            c=getch();
            New(4);tab(4);cout<<setw(30)<<"Player name : "<<A.name<<endl;
            system("cls");
            switch(c)
            {
            case '1' :
                        New(1);tab(4);cout<<setw(30)<<" Enter the Name : ";char n_name[50];gets(n_name);
                        strcpy(A.name,n_name);
                        New(5);tab(5);cout<<"player's name changed successfully.............";getch();
                break;
            case '2' :
                        New(1);tab(4);cout<<setw(30)<<"DOB : "<<A.DOB<<endl;
                        New(1);tab(4);cout<<setw(30)<<"Enter New DOB ( format : DD-MM-YYYY ) : ";char n_DOB[12];gets(n_DOB);
                        strcpy(A.DOB,n_DOB);
                        New(5);tab(4);cout<<"player's DOB changed Successfully..........";getch();

                break;
            }
            temp.write((char*)&A,sizeof(A));
            n=1;
        }
        else
        temp.write((char*)&A,sizeof(A));
    }
    if(n!=1)
    {
        New(3);tab(5);cout<<"Player Not found..........";
        New(2);tab(4);cout<<"press any key to continue...............";getch();getch();
    }
        temp.close();
        change.close();
        remove("profiles.txt");
        rename("temp.txt","profiles.txt");
        remove("temp.txt");
    }
 void update_rec(Admin A)
 {
     int n=0;
     system("cls");
    New(5);tab(4);cout<<"Enter the name of the player to change details : ";char name_s[50];gets(name_s);
    fstream change,temp;
    change.open("profiles.txt",ios::in);
    temp.open("temp.txt",ios::out);
    char c;
    while(change.read((char*)&A,sizeof(A)))
    {
        if(stricmp(name_s,A.name)==0||stricmp(name_s,A.id)==0)
        {
            system("cls");
            New(8);tab(6);cout<<"Player Found.........";Sleep(2000);
            do{
            system("cls");
            New(1);tab(4);dash(strlen(A.name)+15);
            New(1);tab(4);cout<<"Player name : "<<A.name;
            New(1);tab(4);dash(strlen(A.name)+15);
            New(4);tab(5);cout<<"[1] Update Player's team";
            New(2);tab(5);cout<<"[2] Update total Matches played";
            New(2);tab(5);cout<<"[3] Update total runs";
            New(2);tab(5);cout<<"[4] Update highest individual score";
            New(2);tab(5);cout<<"[5] Update no. of 50's";
            New(2);tab(5);cout<<"[6] Update no. of 100's";
            New(2);tab(5);cout<<"[7] Update Batting Average";
            New(2);tab(5);cout<<"[8] Update total wickets";
            New(2);tab(5);cout<<"[9] Update best bowling performance";
            New(2);tab(5);cout<<"[\\] Go Back";

            c=getch();
            system("cls");
            switch(c)
            {
                case '1' : New(2);tab(4);cout<<setw(30)<<"Current team : "<<A.team<<endl;
                           New(1);tab(4);cout<<setw(30)<<"Choose New Team : ";
                           New(5);tab(4);cout<<"[1] Mumbai Indians\t[2] Chennai Super Kings\n";
    New(3);tab(4);cout<<"[3] Rajasthan Royals\t[4] Royal Challengers Bangalore\n";
    New(3);tab(4);cout<<"[5] Kings XI Punjab\t[6] Kolkata Knight Riders\n";
    New(3);tab(4);cout<<"[7] Delhi Daredevils\t[8] Sun Risers Hyderabad\n";
    char team_r;team_r=getch();
    switch(team_r)
    {
        case '1' : strcpy(A.team,"Mumbai Indians");
        break;
        case '2' : strcpy(A.team,"Chennai Super Kings");
        break;
        case '3' : strcpy(A.team,"Rajasthan Royals");
        break;
        case '4' : strcpy(A.team,"Royal Challengers Bangalore");
        break;
        case '5' : strcpy(A.team,"Kings XI Punjab");
        break;
        case '6' : strcpy(A.team,"Kolkata Knight Riders");
        break;
        case '7' : strcpy(A.team,"Delhi Daredevils");
        break;
        case '8' : strcpy(A.team,"Sun Risers Hyderabad");
    }
    New(4);tab(4);cout<<"Player's new team updated Successfully...........";
                break;
                case '2' : New(2);tab(4);cout<<setw(30)<<"Current no. of total Matches : "<<A.total_matches<<endl;
                        New(1);tab(4);cout<<"Updated No. of total Matches : ";char n_matches[7];gets(n_matches);
                        strcpy(A.total_matches,n_matches);
                        New(4);tab(4);cout<<"Player's no. of total matches updated Successfully...........";
                break;
                case '3' :  New(2);tab(4);cout<<setw(30)<<"Current total Runs in IPL Career : "<<A.total_runs<<endl;
                        New(1);tab(4);cout<<setw(30)<<"Updated total runs : ";char n_runs[7];gets(n_runs);
                        strcpy(A.total_runs,n_runs);
                        New(4);tab(4);cout<<"player's total runs updated Successfully..........";
                break;
                case '4' :  New(2);tab(4);cout<<setw(30)<<"Current highest individual Score : "<<A.top_score<<endl;
                        New(1);tab(4);cout<<setw(30)<<"Updated highest individual Score (use '*' after runs for representing not out) : ";char n_score[7];gets(n_score);
                        New(1);tab(5);cout<<"Highest Score Made Against team : ";fflush(stdin);
     New(5);tab(4);cout<<"[1] Mumbai Indians\t[2] Chennai Super Kings\n";
    New(1);tab(4);cout<<"[3] Rajasthan Royals\t[4] Royal Challengers Bangalore\n";
    New(1);tab(4);cout<<"[5] Kings XI Punjab\t[6] Kolkata Knight Riders\n";
    New(1);tab(4);cout<<"[7] Delhi Daredevils\t[8] Sun Risers Hyderabad\n";
    char team_c;team_c=getch();
    switch(team_c)
    {
        case '1' : strcpy(A.opp_team,"Mumbai Indians");
        break;
        case '2' : strcpy(A.opp_team,"Chennai Super Kings");
        break;
        case '3' : strcpy(A.opp_team,"Rajasthan Royals");
        break;
        case '4' : strcpy(A.opp_team,"Royal Challengers Bangalore");
        break;
        case '5' : strcpy(A.opp_team,"Kings XI Punjab");
        break;
        case '6' : strcpy(A.opp_team,"Kolkata Knight Riders");
        break;
        case '7' : strcpy(A.opp_team,"Delhi Daredevils");
        break;
        case '8' : strcpy(A.opp_team,"Sun Risers Hyderabad");
        break;
    }


                        strcpy(A.top_score,n_score);
                        New(4);tab(4);cout<<"player's highest individual Score updated Successfully..........";
                break;
                case '5' :  New(2);tab(4);cout<<setw(30)<<"Current no. of 50's : "<<A.fifties<<endl;
                        New(1);tab(4);cout<<setw(30)<<"Updated no. of 50's : ";char n_fifties[7];gets(n_fifties);
                        strcpy(A.fifties,n_fifties);
                        New(4);tab(4);cout<<"player's no. of 50's updated Successfully..........";
                break;
                case '6' :  New(2);tab(4);cout<<setw(30)<<"Current no. of 100's : "<<A.hundreds<<endl;
                        New(1);tab(4);cout<<setw(30)<<"Updated no. of 100's : ";char n_hundreds[7];gets(n_hundreds);
                        strcpy(A.hundreds,n_hundreds);
                        New(4);tab(4);cout<<"player's no. of 100's updated Successfully..........";
                break;
                case '7' :  New(2);tab(4);cout<<setw(30)<<"Current Batting average : "<<A.average<<endl;
                        New(1);tab(4);cout<<setw(30)<<"Updated Batting average : ";char n_average[7];gets(n_average);
                        strcpy(A.average,n_average);
                        New(4);tab(4);cout<<"player's Batting average updated Successfully..........";
                break;
                case '8' :  New(2);tab(4);cout<<setw(30)<<"Current total wickets taken : "<<A.wickets<<endl;
                        New(1);tab(4);cout<<setw(30)<<"Updated total wickets taken : ";char n_wickets[7];gets(n_wickets);
                        strcpy(A.wickets,n_wickets);
                        New(4);tab(4);cout<<"player's total wickets taken updated Successfully..........";
                break;
                case '9' :  New(2);tab(4);cout<<setw(30)<<"Current best bowling performance : "<<A.top_bowling<<endl;
                        New(1);tab(4);cout<<setw(30)<<"Updated best bowling performance (format : Wickets/Runs) : ";char n_top_bowling[7];gets(n_top_bowling);
                        strcpy(A.top_bowling,n_top_bowling);
                        New(4);tab(4);cout<<"player's best bowling performance updated Successfully..........";
                break;
            }
            New(2);tab(4);cout<<"press any key to continue...............";getch();
            }while(c!='\\');
            temp.write((char*)&A,sizeof(A));
            n=1;
        }
        else
        {
            temp.write((char*)&A,sizeof(A));
        }
 }
        if(n!=1)
        {
            New(3);tab(5);cout<<"player not found.........";getch();
            New(2);tab(4);cout<<"press any key to continue...............";getch();
        }
        temp.close();
        change.close();
        remove("profiles.txt");
        rename("temp.txt","profiles.txt");
        remove("temp.txt");
 }
 void delete_player(Admin A)
 {
     char del_name[50];char ch;
     system("cls");
     New(8);tab(5);cout<<"Enter the name of the player to delete : ";gets(del_name);
     fstream del("profiles.txt",ios::in);
     fstream temp("temp.txt",ios::out);
     while (del.read((char*)&A,sizeof(A)))
     {
         if(stricmp(A.name,del_name)==0)
         {
             again:system("cls");
             New(4);tab(4);cout<<setw(30)<<"Player name : "<<A.name;
             New(2);tab(4);cout<<setw(30)<<"Player's Team : "<<A.team;
             New(4);tab(4);cout<<"press y for Yes and n for no : ";ch=getche();
             switch(ch)
             {
             case 'y' :New(5);tab(5);cout<<"Player deleted successfully.............";
                  continue;
             break;
             case 'n' : New(5);tab(5);cout<<"Player not deleted.............";
                 temp.write((char*)&A,sizeof(A));
             break;
             default : goto again;
             }
         }
         else
            temp.write((char*)&A,sizeof(A));
     }
     New(5);tab(5);cout<<"press any key to continue............";getch();
     del.close();
     temp.close();
     remove("profiles.txt");
     rename("temp.txt","profiles.txt");
     remove("temp.txt");

 }
int main()
{	USER Sche;
    WRAP W;
    char choice;
    do
    {
        main_s:
        system("cls");
        system("color 16");
        Beep(1600,10);
        New(3);tab(2);tilde(206);New(2);tab(2);tilde(206);New(2);tab(2);tilde(206);New(2);tab(2);tilde(206);
        New(2);tab(10);cout<<"[1] ACCESS THE INFORMATION";
        New(2);tab(10);cout<<"[2] UPDATE OR ADD THE INFORMATION";
        New(2);tab(10);cout<<"[3] GET MATCH SCHEDULE";
        New(2);tab(10);cout<<"[4] Exit";
         New(2);tab(2);tilde(206);New(2);tab(2);tilde(206);New(2);tab(2);tilde(206);New(2);tab(2);tilde(206);
        tab(2);choice=getch();
        if(choice)
        {
        Beep(1600,10);
    	}
        switch(choice)
        {
        case '1' : user();
            break;
        case '2' : admin();
            break;
        case '3' :Sche.see_schedule();
        	break;
        case '4' : exit(0);
        }
    }
    while(choice!='4');
}
void user()
{			//Calling class -- USER[see_schedule(),see_by_date(] , matches_by_date , points1 
  
    USER Value;
    matches_by_date r;
    //points1 p;
    char ch;
    do
    {
    system("cls");
    cout<<"\a";
    system("color 5F");
    New(4);tab(6);cout<<"CHOOSE THE ONE OPTION MENTIONED BELOW.";
    New(1);tab(6);star(100);
    New(4);tab(6);cout<<"[a] Match Schedule";
    New(2);tab(6);cout<<"[b] Get Player Details";
    New(2);tab(6);cout<<"[c] Team Players";
    New(2);tab(6);cout<<"[d] Get Matches By dates"; 
    New(2);tab(6);cout<<"[e] Man of the Matches";
  
    New(5);tab(12);cout<<"[\\] Go Back";
    ch=getch();
    if(getch())
    {
    	Beep(1600,10);
	}
    switch(ch)
    {
    case 'a' : Value.see_schedule();
        break;
    case 'd' : Value.see_by_date();
        break;
    case 'b' : search_player(Value);
        break;
    case 'e' : r.see_man_match(r);
        break;
    case 'c' : players_list(Value);
        break;
    
    }
    }
    while(ch!='\\');
    system("color F1");
};

void admin()
{
//	string filedetails;
	
    fstream profile;
    ofstream file;
    Admin A;
    USER B;
    //points1 r;
    matches_by_date p;
    again:system("cls");
    system("color 20");
    
    New(4);tab(2);star(206);New(2);tab(2);star(206);New(2);tab(2);star(206);New(2);tab(2);star(206);
    New(4);tab(11);cout<<"Please Enter the Password : ";char pass[30];string password="aman@ipl2019";
    
    char q;
    int i=0;
    while((q=getch())!=13)
	{
		if(q==8)
		{
			pass[0]='\0';
			i=0;
			goto again;
		}
		printf("*");
		Beep(1600,10);
		pass[i]=q;
		i++;
		
	}
	
	pass[i]='\0';
	New(4);tab(2);star(206);New(2);tab(2);star(206);New(2);tab(2);star(206);New(2);tab(2);star(206);
	for(int i=0;i<4;i++)
    {
        system("cls");
		system("color 90");New(10);tab(11);cout<<"Verifying User......Please wait \\";tab(3);Sleep(111);
	system("cls");system("color 90");New(10);tab(11);cout<<"Verifying User......Please wait |";tab(3);Sleep(111);
	system("cls");system("color 90");New(10);tab(11);cout<<"Verifying User......Please wait /";tab(3);Sleep(111);
	system("cls");system("color 90");New(10);tab(11);cout<<"Verifying User......Please wait |";tab(3);Sleep(111);
    }
    if(password.compare(pass)!=0)
    {
    	system("cls");New(10);tab(11);cout<<"Password did not Matched !!!!!";
    	New(6);tab(11);cout<<"Please Enter the right password.";getch();
    	goto again;
	}
	system("cls");New(11);tab(13);cout<<"User Varified successfully....";Sleep(1875);
	for(int i=0;i<4;i++)
    {
        system("cls");
		system("color 90");New(10);tab(13);cout<<"Getting Details..... \\";tab(3);Sleep(111);
	system("cls");system("color 90");New(10);tab(13);cout<<"Getting Details..... |";tab(3);Sleep(111);
	system("cls");system("color 90");New(10);tab(13);cout<<"Getting Details..... /";tab(3);Sleep(111);
	system("cls");system("color 90");New(10);tab(13);cout<<"Getting Details..... |";tab(3);Sleep(111);
	}
     char b;
     do{
            rs:
    system("cls");
    system("color 3F");
    cout<<"\a";
    New(3);tab(3);cout<<"[a] See Schedule";
    New(0);tab(3);cout<<"[b] Search Matches on the dates";
    New(3);tab(3);cout<<"[c] Add a player";
    New(0);tab(3);cout<<"[d] Search Player Details";
    New(0);tab(3);cout<<"[e] Edit Player Details";
    New(3);tab(3);cout<<"[f] Delete a Player";
    New(3);tab(3);cout<<"[g] Add a match";
    New(0);tab(4);cout<<"[h] Logout";
    New(3);tab(3);cout<<"[z] Exit";
   
    b=getche();fstream det;
    if(getch())
    {
    	Beep(1600,10);
	}
	if(b=='a')
	{
		B.see_schedule();
	}
	else if(b=='b')
	{
		B.see_by_date();
	}
	else if(b=='c')
	{
				
    			file.open("profiles.txt",ios::out);
    		
				A.add_player();
			
    			file.write((char*)&A,sizeof(A));
    			file.close();
	}
	else if(b=='d')
	{
		search_player(B);
	}
	else if(b=='e')
	{
		edit_details();
	
	}
	else if(b=='g')
	{
		p.update_m_d(A);
        det.open("dates_match_details.txt",ios::app|ios::out);
        det.write((char*)&p,sizeof(p));
        det.close();
	}
	else if(b=='f')
	{
		delete_player(A);
	}
	else if(b=='h')
	{
		r_ag:system("cls");New(8);tab(4);cout<<"Are you sure You want to logout ? [y/n] ";char t = getche();
    if(t=='n')
    goto rs;
    else if(t!='y')
        goto r_ag;
    else {system("cls");New(8);tab(5);cout<<"Logging you out...........";Sleep(1500);}
        
	}
	else if(b=='z')
	{
		exit(0);
	}
    
     }while(b!='l');
     system("color F1");
}
void edit_details()
{
    Admin A;
    char b;
    do{
    system("cls");
    New(5);tab(5);cout<<"[1] Edit player's biodata";
    New(2);tab(5);cout<<"[2] Update player's IPL record";
    New(2);tab(5);cout<<"[3] Go Back";
    b=getch();
    switch(b)
    {
    case '1' : change_bio(A);
        break;
    case '2' : update_rec(A);
    break;
    }
    }while(b!='3');
}
